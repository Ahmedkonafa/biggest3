
# 🎬 Bgbest Cinema Platform - Global Launch Guide

منصتك الآن جاهزة للانطلاق للعالمية! اتبع هذا الدليل لفتح الموقع لكل الجمهور.

## 🚀 الخطوة 1: النشر على Vercel (مجاناً)
1. قم بإنشاء حساب على [GitHub](https://github.com/) وارفع عليه هذا الكود.
2. ادخل على [Vercel](https://vercel.com/) واضغط على **"Add New Project"**.
3. اختر المستودع (Repository) الخاص بالمشروع.
4. **هام جداً:** في قسم **Environment Variables**، أضف مفتاحك:
   - Key: `API_KEY`
   - Value: `ضع_مفتاح_GEMINI_الخاص_بك`
5. اضغط **Deploy**. الآن موقعك يعمل برابط مثل `bgbest.vercel.app`.

## 🌐 الخطوة 2: ربط نطاق (Domain)
إذا كنت تملك نطاقاً مثل `bgbest.com`:
1. اذهب لـ **Settings > Domains** في Vercel.
2. أضف النطاق واتبع تعليمات الـ DNS.

## 💰 الخطوة 3: تفعيل الربح
1. اذهب إلى **لوحة الإدارة** في موقعك الجديد.
2. سجل دخولك ببريد الأدمن: `admin@bgbest.com`.
3. ادخل تبويب **"الأرباح"** وضع كود إعلاناتك.

---
**Bgbest v2.5.0-Global** | جميع الحقوق محفوظة.


export interface AppNotification {
  id: string;
  title: string;
  message: string;
  date: string;
  isRead: boolean;
  link: string;
  type: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
  plan: 'free' | 'premium';
  status: 'active' | 'blocked';
  joinedDate: string;
}

export interface MediaItem {
  id: string;
  title: string;
  description: string;
  posterUrl: string;
  backdropUrl: string;
  category: string;
  rating: number;
  year: number;
  type: 'movie' | 'series';
  videoUrl: string;
  downloadLinks?: { server: string; quality: string; size: string; url: string; isPremium?: boolean; }[];
  isDubbed?: boolean;
  isPremiumOnly?: boolean;
}


import React, { useState, useEffect } from 'react';

interface CinematicIntroProps {
  onComplete: () => void;
}

const CinematicIntro: React.FC<CinematicIntroProps> = ({ onComplete }) => {
  const [stage, setStage] = useState<'dark' | 'reveal' | 'ready'>('dark');

  useEffect(() => {
    const timer1 = setTimeout(() => setStage('reveal'), 1000);
    const timer2 = setTimeout(() => setStage('ready'), 3500);
    return () => { clearTimeout(timer1); clearTimeout(timer2); };
  }, []);

  const handleEnter = () => {
    setStage('dark');
    setTimeout(onComplete, 1200);
  };

  return (
    <div className={`fixed inset-0 z-[9999] bg-[#000] flex flex-col items-center justify-center transition-all duration-[2000ms] ${stage === 'dark' && 'opacity-100'}`}>
      
      {/* Cinematic Ambience Overlay */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className={`absolute inset-0 bg-gradient-to-t from-black via-transparent to-black z-10 transition-opacity duration-[2000ms] ${stage !== 'dark' ? 'opacity-100' : 'opacity-0'}`}></div>
        <div className="absolute inset-0 bg-black/40 z-0"></div>
        {/* Subtle Smoke/Nebula Video */}
        <video autoPlay muted loop playsInline className={`w-full h-full object-cover transition-all duration-[4000ms] ${stage !== 'dark' ? 'opacity-20 scale-100 blur-md' : 'opacity-0 scale-150 blur-2xl'}`}>
          <source src="https://assets.mixkit.co/videos/preview/mixkit-nebula-in-outer-space-4040-large.mp4" type="video/mp4" />
        </video>
      </div>

      {/* Main Logo & Subtext */}
      <div className="relative z-20 text-center">
        <div className={`transition-all duration-[3000ms] ease-out transform ${stage !== 'dark' ? 'scale-100 opacity-100 translate-y-0' : 'scale-75 opacity-0 translate-y-20'}`}>
          <h1 className="text-[10rem] md:text-[20rem] font-black italic text-white tracking-tighter drop-shadow-[0_0_80px_rgba(56,189,248,0.4)] leading-none select-none">
            Bgbest
          </h1>
          <div className="flex flex-col items-center mt-8 space-y-4">
            <div className={`h-[1px] bg-sky-500 shadow-[0_0_30px_#38bdf8] transition-all duration-[2500ms] ${stage === 'ready' ? 'w-[400px] opacity-100' : 'w-0 opacity-0'}`}></div>
            <div className={`transition-all duration-1000 delay-700 ${stage === 'ready' ? 'opacity-100' : 'opacity-0'}`}>
              <p className="text-sky-500 font-black tracking-[1em] text-sm uppercase">Bgbest Cinema</p>
              <p className="text-gray-500 font-bold tracking-[0.4em] text-xs uppercase mt-2">بي جي بيست سينما</p>
            </div>
          </div>
        </div>
      </div>

      {/* Enter Button - More Atmospheric */}
      {stage === 'ready' && (
        <button 
          onClick={handleEnter} 
          className="absolute bottom-24 z-30 group animate-in fade-in slide-in-from-bottom-20 duration-1000 flex flex-col items-center gap-8"
        >
          <div className="relative">
            <div className="absolute inset-0 bg-sky-500 blur-3xl opacity-20 group-hover:opacity-40 transition-opacity"></div>
            <div className="relative px-20 py-8 rounded-full bg-white text-black font-black text-2xl tracking-[0.2em] uppercase hover:bg-sky-500 hover:text-white transition-all transform hover:scale-105 active:scale-95 shadow-[0_0_100px_rgba(255,255,255,0.1)] leading-none">
               اقتحام الأعماق
            </div>
          </div>
          <p className="text-[10px] font-black tracking-[0.5em] text-gray-500 uppercase animate-pulse">Click to breach the singularity</p>
        </button>
      )}

      {/* Vignette effect */}
      <div className="absolute inset-0 shadow-[inset_0_0_200px_rgba(0,0,0,1)] pointer-events-none z-40"></div>
    </div>
  );
};

export default CinematicIntro;

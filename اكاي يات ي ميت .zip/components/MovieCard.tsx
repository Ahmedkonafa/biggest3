
import React from 'react';
import { Link } from 'react-router-dom';
import { MediaItem } from '../types';

interface MovieCardProps {
  item: MediaItem;
}

const MovieCard: React.FC<MovieCardProps> = ({ item }) => {
  return (
    <Link to={`/media/${item.id}`} className="group relative block overflow-hidden rounded-[3rem] transition-all duration-700 hover:scale-[1.05] shadow-[0_30px_60px_rgba(0,0,0,0.8)] border border-white/5 bg-[#050505]">
      <div className="aspect-[2/3] w-full overflow-hidden relative">
        <img src={item.posterUrl} alt={item.title} className="h-full w-full object-cover transition-all duration-[1500ms] group-hover:scale-110 group-hover:brightness-[0.4]" loading="lazy" />
        
        {/* Play Icon Overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-500">
           <div className="bg-[#38bdf8] p-6 rounded-full shadow-[0_0_50px_rgba(56,189,248,0.6)] transform scale-0 group-hover:scale-100 transition-transform duration-500">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white fill-current" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
              </svg>
           </div>
        </div>

        {/* Floating Label */}
        <div className="absolute top-6 right-6">
           <span className="bg-black/60 backdrop-blur-xl text-white text-[8px] font-black px-4 py-2 rounded-full border border-white/10 uppercase tracking-widest shadow-2xl">
              {item.category}
           </span>
        </div>
      </div>
      
      <div className="p-8">
        <div className="flex items-center gap-3 mb-3">
          <span className="text-[#38bdf8] text-[10px] font-black tracking-widest">★ {item.rating}</span>
          <div className="h-1 w-1 bg-gray-700 rounded-full"></div>
          <span className="text-[10px] font-black text-gray-500 tracking-widest">{item.year}</span>
        </div>
        <h3 className="text-base font-black text-white group-hover:text-[#38bdf8] transition-colors line-clamp-1 tracking-tight">{item.title}</h3>
      </div>
      
      {/* Decorative Glow */}
      <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-[#38bdf8]/10 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
    </Link>
  );
};

export default MovieCard;


import React, { useState, useRef, useEffect } from 'react';
import { chatWithGeminiStream } from '../services/geminiService';

const GeminiAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  // Added sources to the message interface to display Google Search grounding results
  const [messages, setMessages] = useState<{ role: 'user' | 'model', text: string, sources?: { uri: string, title: string }[] }[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);
    setMessages(prev => [...prev, { role: 'model', text: '', sources: [] }]);

    try {
      let fullText = '';
      let allSources: { uri: string, title: string }[] = [];
      const stream = chatWithGeminiStream(userMsg);
      for await (const chunk of stream) {
        fullText += chunk.text;
        
        // Collect unique sources from the grounding metadata in the response stream
        if (chunk.sources && chunk.sources.length > 0) {
          chunk.sources.forEach((source: { uri: string, title: string }) => {
            if (!allSources.find(s => s.uri === source.uri)) {
              allSources.push(source);
            }
          });
        }

        setMessages(prev => {
          const newMessages = [...prev];
          const lastMsgIndex = newMessages.length - 1;
          newMessages[lastMsgIndex] = {
            ...newMessages[lastMsgIndex],
            text: fullText,
            sources: allSources
          };
          return newMessages;
        });
        setIsLoading(false);
      }
    } catch (e) {
      setMessages(prev => [...prev, { role: 'model', text: "حدث خطأ في المزامنة." }]);
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-24 md:bottom-12 left-12 z-[100]" dir="rtl">
      {isOpen ? (
        <div className="w-80 md:w-[450px] bg-[#050505]/95 backdrop-blur-3xl border border-white/10 rounded-[3rem] shadow-[0_50px_100px_rgba(0,0,0,1)] flex flex-col h-[600px] overflow-hidden animate-in slide-in-from-bottom-12 duration-700">
          <div className="bg-white p-8 flex justify-between items-center shadow-2xl">
            <h3 className="font-black text-black text-xs uppercase tracking-[0.3em]">عقل Bgbest</h3>
            <button onClick={() => setIsOpen(false)} className="text-black hover:opacity-50 font-black">✕</button>
          </div>
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-8 space-y-6 no-scrollbar">
            {messages.length === 0 && <p className="text-gray-500 text-center mt-20 font-bold text-sm">أنا هنا لإرشادك في أعماق Bgbest. اسأل عن أي فيلم أو مسلسل.</p>}
            {messages.map((m, i) => (
              <div key={i} className={`flex flex-col ${m.role === 'user' ? 'items-start' : 'items-end'}`}>
                <div className={`max-w-[90%] p-6 rounded-[2rem] text-[12px] font-bold leading-relaxed ${m.role === 'user' ? 'bg-[#38bdf8] text-white shadow-xl shadow-[#38bdf8]/20' : 'bg-white/5 text-gray-300 border border-white/10'}`}>
                  {m.text}
                </div>
                {/* Display grounding sources if available to comply with Gemini API policies */}
                {m.sources && m.sources.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-2 max-w-[90%] px-4">
                    {m.sources.map((source, sIdx) => (
                      <a 
                        key={sIdx} 
                        href={source.uri} 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="text-[9px] text-[#38bdf8] hover:underline bg-[#38bdf8]/10 px-2 py-1 rounded-full border border-[#38bdf8]/20 transition-all hover:bg-[#38bdf8]/20"
                      >
                        {source.title || 'المصدر'}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
          <div className="p-6 bg-black border-t border-white/5 flex gap-4">
            <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSend()} placeholder="أخبر العقل بما يجول في خاطرك..." className="flex-1 bg-white/[0.03] border border-white/10 rounded-[1.5rem] px-6 py-4 text-sm text-white outline-none focus:border-[#38bdf8] transition-all" />
            <button onClick={handleSend} className="bg-white text-black p-4 rounded-[1.5rem] hover:bg-[#38bdf8] hover:text-white transition-all transform active:scale-90"><svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg></button>
          </div>
        </div>
      ) : (
        <button onClick={() => setIsOpen(true)} className="bg-white w-20 h-20 rounded-full shadow-[0_0_50px_rgba(255,255,255,0.2)] flex items-center justify-center transition-all hover:scale-110 active:scale-90 hover:bg-[#38bdf8] group">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-black group-hover:text-white transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>
        </button>
      )}
    </div>
  );
};

export default GeminiAssistant;

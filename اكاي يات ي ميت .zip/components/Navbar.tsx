
import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AppNotification } from '../types';

const Navbar: React.FC<{ onLogout: () => void }> = ({ onLogout }) => {
  const [watchers, setWatchers] = useState(4290);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications] = useState<AppNotification[]>([
    { id: '1', title: 'تمت إضافة "ولاد رزق 3"', message: 'شاهد الآن أضخم عمل أكشن عربي لهذا العام.', date: 'الآن', isRead: false, link: '/media/m1', type: 'new_movie' },
    { id: '2', title: 'تنبيه الأجواء', message: 'تم تحديث نظام الجسيمات ليكون أكثر غموضاً.', date: 'منذ ساعة', isRead: true, link: '/settings', type: 'system' }
  ]);
  const navigate = useNavigate();
  const notificationRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setWatchers(prev => prev + (Math.random() > 0.5 ? 3 : -3));
    }, 5000);

    const handleClickOutside = (event: MouseEvent) => {
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      clearInterval(interval);
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black/60 backdrop-blur-3xl border-b border-white/5 px-6 py-5" dir="rtl">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-12">
          <Link to="/" className="text-4xl font-black text-white hover:text-[#38bdf8] transition-all italic tracking-tighter">Bgbest</Link>
          <div className="hidden md:flex gap-10 text-[10px] font-black uppercase tracking-[0.3em] text-gray-500">
            <Link to="/" className="text-white hover:text-[#38bdf8] transition-colors">الرئيسية</Link>
            <Link to="/admin" className="hover:text-[#38bdf8] transition-colors">الإدارة</Link>
            <Link to="/settings" className="hover:text-[#38bdf8] transition-colors">الإعدادات</Link>
          </div>
        </div>

        <div className="flex items-center gap-8">
          <div className="hidden lg:flex items-center gap-2 bg-white/5 border border-white/5 px-5 py-2 rounded-full">
            <div className="w-1.5 h-1.5 bg-[#38bdf8] rounded-full animate-pulse shadow-[0_0_10px_#38bdf8]"></div>
            <span className="text-[9px] font-black text-gray-400 uppercase tracking-tighter">المراقبون: <span className="text-white">{watchers.toLocaleString()}</span></span>
          </div>
          
          <div className="relative" ref={notificationRef}>
            <button onClick={() => setShowNotifications(!showNotifications)} className="p-2 text-gray-400 hover:text-[#38bdf8] transition-all relative">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>
              {unreadCount > 0 && <span className="absolute top-2 right-2 h-2 w-2 rounded-full bg-[#38bdf8] shadow-[0_0_10px_#38bdf8]"></span>}
            </button>

            {showNotifications && (
              <div className="absolute top-14 left-0 w-80 bg-[#050505]/95 backdrop-blur-3xl border border-white/10 rounded-[2.5rem] shadow-[0_40px_80px_rgba(0,0,0,1)] overflow-hidden animate-in fade-in zoom-in duration-300">
                <div className="p-6 border-b border-white/5 flex justify-between items-center">
                  <h3 className="font-black text-[10px] text-gray-400 uppercase tracking-widest">تنبيهات المجهول</h3>
                  <span className="text-[8px] bg-[#38bdf8]/20 text-[#38bdf8] px-2 py-1 rounded-full font-black">جديد</span>
                </div>
                <div className="max-h-[300px] overflow-y-auto no-scrollbar">
                  {notifications.map(n => (
                    <Link key={n.id} to={n.link} onClick={() => setShowNotifications(false)} className="block p-6 border-b border-white/5 hover:bg-white/5 transition-all">
                      <div className="flex justify-between items-start mb-1">
                        <span className="font-black text-[11px] text-white line-clamp-1">{n.title}</span>
                        <span className="text-[8px] text-gray-700 font-bold">{n.date}</span>
                      </div>
                      <p className="text-[10px] text-gray-500 font-bold leading-relaxed">{n.message}</p>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          <button onClick={() => { if(window.confirm('هل تود مغادرة هذا العالم العميق؟')) { onLogout(); navigate('/login'); }}} className="text-gray-600 hover:text-white p-2 transition-all">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7" /></svg>
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;


import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { MOCK_MEDIA } from '../constants';
import { MediaItem } from '../types';

const MovieDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [showPlayer, setShowPlayer] = useState(false);
  const [media, setMedia] = useState<MediaItem | null>(null);

  useEffect(() => {
    const savedMedia = localStorage.getItem('bgbest_custom_media');
    const allMedia: MediaItem[] = savedMedia ? JSON.parse(savedMedia) : MOCK_MEDIA;
    const found = allMedia.find(m => m.id === id);
    setMedia(found || null);
    window.scrollTo(0, 0);
  }, [id]);

  if (!media) return <div className="pt-40 text-center text-[#38bdf8] font-black">جاري البحث في الأعماق...</div>;

  return (
    <div className="min-h-screen pb-32 bg-black text-right" dir="rtl">
      <div className="relative h-[85vh] w-full">
        <img src={media.backdropUrl || media.posterUrl} className="w-full h-full object-cover brightness-[0.2] contrast-125 blur-sm" alt="" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-transparent"></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 -mt-[50vh] relative z-10">
        <div className="flex flex-col lg:flex-row gap-20 items-start">
          <div className="w-80 md:w-[450px] flex-shrink-0 shadow-[0_50px_100px_rgba(0,0,0,1)] rounded-[4rem] overflow-hidden border border-white/5 group relative">
             <img src={media.posterUrl} className="w-full aspect-[2/3] object-cover transition-transform duration-1000 group-hover:scale-105" alt="" />
             <div className="absolute inset-0 bg-[#38bdf8]/10 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
          </div>

          <div className="flex-1 lg:pt-40">
             <div className="flex items-center gap-5 mb-10">
                <span className="bg-[#38bdf8] text-white px-10 py-3 rounded-full font-black text-[10px] uppercase tracking-[0.3em] shadow-[0_10px_30px_rgba(56,189,248,0.4)]">{media.category}</span>
                <span className="text-gray-500 font-black text-sm tracking-widest uppercase">Release Year: {media.year}</span>
             </div>
             <h1 className="text-7xl md:text-[10rem] font-black mb-12 tracking-tighter text-white leading-none">{media.title}</h1>
             <div className="bg-white/[0.03] backdrop-blur-3xl p-16 rounded-[4rem] border border-white/5 mb-16 shadow-2xl">
                <p className="text-gray-400 text-2xl leading-[1.8] font-bold">{media.description}</p>
             </div>
             
             <div className="flex flex-wrap gap-10">
                <button onClick={() => setShowPlayer(true)} className="bg-white hover:bg-[#38bdf8] text-black hover:text-white font-black px-24 py-8 rounded-[2.5rem] text-3xl transition-all transform hover:scale-105 active:scale-95 flex items-center gap-8 shadow-[0_30px_80px_rgba(255,255,255,0.1)]">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 fill-current" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" /></svg>
                  فك التشفير والمشاهدة
                </button>
             </div>
          </div>
        </div>

        {showPlayer && (
          <div className="fixed inset-0 z-[100] bg-black/98 flex items-center justify-center p-8 backdrop-blur-3xl animate-in fade-in duration-500">
            <button onClick={() => setShowPlayer(false)} className="absolute top-12 left-12 text-white hover:text-[#38bdf8] z-[110] bg-white/5 p-8 rounded-full border border-white/10 transition-all hover:scale-110">
               <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
            <div className="w-full max-w-7xl aspect-video rounded-[4rem] overflow-hidden border border-white/10 shadow-[0_0_200px_rgba(56,189,248,0.1)] bg-black">
               <iframe src={media.videoUrl} className="w-full h-full" allowFullScreen></iframe>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MovieDetails;

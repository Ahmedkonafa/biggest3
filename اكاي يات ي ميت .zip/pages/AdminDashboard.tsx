
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { MOCK_MEDIA } from '../constants';
import { User, MediaItem } from '../types';

const AdminDashboard: React.FC = () => {
  const [mediaList, setMediaList] = useState<MediaItem[]>([]);
  const [usersList, setUsersList] = useState<User[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [showModal, setShowModal] = useState(false);
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    title: '', posterUrl: '', backdropUrl: '', category: 'أكشن',
    year: new Date().getFullYear(), description: '', rating: 8.5,
    type: 'movie' as 'movie' | 'series', videoUrl: '',
    isDubbed: false, isPremiumOnly: false
  });

  useEffect(() => {
    const userStr = localStorage.getItem('bgbest_user');
    if (!userStr || JSON.parse(userStr).role !== 'admin') {
      navigate('/login');
      return;
    }
    
    const savedMedia = localStorage.getItem('bgbest_custom_media');
    setMediaList(savedMedia ? JSON.parse(savedMedia) : MOCK_MEDIA);
    
    const savedUsers = localStorage.getItem('bgbest_users_db');
    setUsersList(savedUsers ? JSON.parse(savedUsers) : []);

    const savedNotifs = localStorage.getItem('bgbest_admin_notifications');
    setNotifications(savedNotifs ? JSON.parse(savedNotifs) : []);
  }, [navigate]);

  const handleSaveMedia = (e: React.FormEvent) => {
    e.preventDefault();
    const newItem: MediaItem = { ...formData, id: 'm_' + Date.now() };
    const newList = [newItem, ...mediaList];
    setMediaList(newList);
    localStorage.setItem('bgbest_custom_media', JSON.stringify(newList));
    setShowModal(false);
    
    const newNotif = { id: Date.now(), title: 'محتوى جديد', message: `تم نشر ${newItem.title} بنجاح.`, date: 'الآن', isRead: false };
    const updatedNotifs = [newNotif, ...notifications];
    setNotifications(updatedNotifs);
    localStorage.setItem('bgbest_admin_notifications', JSON.stringify(updatedNotifs));
    
    setFormData({
      title: '', posterUrl: '', backdropUrl: '', category: 'أكشن',
      year: new Date().getFullYear(), description: '', rating: 8.5,
      type: 'movie', videoUrl: '', isDubbed: false, isPremiumOnly: false
    });
  };

  const toggleUserStatus = (userId: string) => {
    const updatedUsers = usersList.map(u => {
      if (u.id === userId) {
        const newStatus = u.status === 'active' ? 'blocked' : 'active';
        return { ...u, status: newStatus };
      }
      return u;
    });
    setUsersList(updatedUsers as User[]);
    localStorage.setItem('bgbest_users_db', JSON.stringify(updatedUsers));
  };

  const clearNotifications = () => {
    localStorage.setItem('bgbest_admin_notifications', JSON.stringify([]));
    setNotifications([]);
  };

  return (
    <div className="pt-28 pb-32 px-6 max-w-7xl mx-auto text-right min-h-screen" dir="rtl">
      
      <div className="flex flex-col md:flex-row justify-between items-end gap-10 mb-20">
        <div className="space-y-4">
          <h1 className="text-6xl md:text-8xl font-black text-white italic tracking-tighter">قمرة <span className="text-sky-500">التحكم</span></h1>
          <p className="text-gray-500 font-bold tracking-[0.3em] uppercase text-xs">Bgbest Central Command System</p>
        </div>
        <button onClick={() => setShowModal(true)} className="bg-white text-black font-black px-12 py-7 rounded-[2.5rem] shadow-2xl hover:bg-sky-500 hover:text-white transition-all transform active:scale-95 text-xl">
          + إضافة محتوى جديد
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
        <div className="bg-white/[0.02] p-12 rounded-[3.5rem] border border-white/5 backdrop-blur-3xl shadow-2xl">
          <p className="text-[10px] text-gray-500 font-black uppercase tracking-widest mb-4">قاعدة البيانات</p>
          <div className="flex items-baseline gap-4">
             <p className="text-7xl font-black text-white">{mediaList.length}</p>
             <p className="text-sky-500 font-black text-xs">عمل فني</p>
          </div>
        </div>

        <div className="bg-white/[0.02] p-12 rounded-[3.5rem] border border-white/5 backdrop-blur-3xl shadow-2xl">
          <p className="text-[10px] text-gray-500 font-black uppercase tracking-widest mb-4">مجتمع الأعماق</p>
          <div className="flex items-baseline gap-4">
             <p className="text-7xl font-black text-white">{usersList.length}</p>
             <p className="text-sky-500 font-black text-xs">عضو مسجل</p>
          </div>
        </div>

        <div className="lg:col-span-2 bg-[#080808] p-10 rounded-[3.5rem] border border-white/10 shadow-inner relative overflow-hidden">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-sm font-black text-white flex items-center gap-3">
               <div className="w-2 h-2 bg-sky-500 rounded-full animate-ping"></div>
               النشاط الحالي
            </h3>
            {notifications.length > 0 && (
              <button onClick={clearNotifications} className="text-[9px] font-black text-gray-700 hover:text-red-500 uppercase tracking-widest">مسح السجل</button>
            )}
          </div>
          <div className="space-y-3 max-h-[140px] overflow-y-auto no-scrollbar">
            {notifications.length === 0 ? (
              <p className="text-center py-10 text-gray-700 text-xs font-black uppercase tracking-widest">المجرة هادئة حالياً</p>
            ) : (
              notifications.map(n => (
                <div key={n.id} className="flex items-center gap-5 bg-white/[0.03] p-4 rounded-2xl border border-white/5">
                  <div className="w-1 h-1 bg-sky-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-[11px] font-black text-white">{n.title}</p>
                    <p className="text-[9px] text-gray-500 font-bold">{n.message}</p>
                  </div>
                  <span className="text-[8px] text-gray-700 font-black">{n.date}</span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      <div>
         <h2 className="text-2xl font-black text-white mb-10 border-r-4 border-sky-500 pr-5 italic">إدارة المستخدمين والحالات</h2>
         <div className="bg-[#050505] rounded-[3rem] border border-white/5 overflow-hidden shadow-2xl">
            <table className="w-full text-right">
               <thead>
                  <tr className="bg-white/5 text-[10px] font-black text-gray-500 uppercase tracking-widest">
                     <th className="p-10">الاسم والصفة</th>
                     <th className="p-10">البريد الإلكتروني</th>
                     <th className="p-10 text-center">الحالة</th>
                     <th className="p-10 text-center">الإجراء</th>
                  </tr>
               </thead>
               <tbody className="divide-y divide-white/5">
                  {usersList.length === 0 ? (
                    <tr><td colSpan={4} className="p-20 text-center text-gray-600 font-black italic">لا يوجد مستخدمون حالياً</td></tr>
                  ) : (
                    usersList.map(u => (
                      <tr key={u.id} className="hover:bg-white/[0.01] transition-all group">
                         <td className="p-10 font-black text-white text-base">
                            <div className="flex items-center gap-3">
                               <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-[10px] font-black group-hover:bg-sky-500/20 group-hover:text-sky-500 transition-all">
                                  {u.name.charAt(0)}
                               </div>
                               <span>{u.name}</span>
                            </div>
                         </td>
                         <td className="p-10 font-bold text-gray-400 text-sm">{u.email}</td>
                         <td className="p-10 text-center">
                            <span className={`px-5 py-1.5 rounded-full text-[10px] font-black uppercase border transition-all ${u.status === 'active' ? 'bg-green-500/10 text-green-500 border-green-500/20' : 'bg-red-500/10 text-red-500 border-red-500/20 shadow-[0_0_20px_rgba(239,68,68,0.15)] animate-pulse'}`}>
                               {u.status === 'active' ? 'نشط' : 'محظور'}
                            </span>
                         </td>
                         <td className="p-10 text-center">
                            <button 
                              onClick={() => toggleUserStatus(u.id)} 
                              className={`text-[11px] font-black transition-all px-4 py-2 rounded-xl border border-transparent hover:border-current ${u.status === 'active' ? 'text-red-400 hover:text-red-600' : 'text-sky-500 hover:text-white'}`}
                            >
                              {u.status === 'active' ? 'حظر الحساب' : 'فك الحظر'}
                            </button>
                         </td>
                      </tr>
                    ))
                  )}
               </tbody>
            </table>
         </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 z-[200] bg-black/95 backdrop-blur-2xl flex items-center justify-center p-6 animate-in fade-in duration-300">
           <form onSubmit={handleSaveMedia} className="bg-[#050505] w-full max-w-4xl p-16 rounded-[4rem] border border-white/10 shadow-[0_0_100px_rgba(56,189,248,0.1)] space-y-10">
              <h2 className="text-4xl font-black text-white italic">نشر <span className="text-sky-500">عمل جديد</span></h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 <input required value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} className="w-full bg-white/[0.03] border border-white/10 p-6 rounded-3xl text-white font-bold outline-none focus:border-sky-500 transition-all" placeholder="اسم العمل" />
                 <input value={formData.posterUrl} onChange={e => setFormData({...formData, posterUrl: e.target.value})} className="w-full bg-white/[0.03] border border-white/10 p-6 rounded-3xl text-white font-bold outline-none" placeholder="رابط البوستر" />
              </div>
              <textarea required value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="w-full bg-white/[0.03] border border-white/10 p-6 rounded-[2.5rem] h-40 text-gray-400 outline-none" placeholder="ملخص القصة..."></textarea>
              <div className="flex gap-6">
                <button type="submit" className="flex-1 bg-white text-black font-black py-7 rounded-3xl hover:bg-sky-500 hover:text-white transition-all text-xl shadow-xl">نشر الآن</button>
                <button type="button" onClick={() => setShowModal(false)} className="px-10 py-7 bg-white/5 text-gray-500 rounded-3xl font-black transition-colors hover:text-white">إلغاء</button>
              </div>
           </form>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;

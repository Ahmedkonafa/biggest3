
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface LoginProps {
  onLogin: () => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [mode, setMode] = useState<'login' | 'signup' | 'verify'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [userOtp, setUserOtp] = useState('');
  const [tempUser, setTempUser] = useState<any>(null);

  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  const validatePassword = (pass: string) => {
    return /^(?=.*[A-Z]).{8,}$/.test(pass);
  };

  const sendRealEmail = async (targetEmail: string, otp: string) => {
    // محاكاة الإرسال الحقيقي
    return new Promise((resolve) => {
      setTimeout(() => {
        alert(`🎬 Bgbest Cinema | بي جي بيست سينما\n--------------------------------\nتم إرسال شفرة التحقق: ${otp}\nالوجهة: ${targetEmail}`);
        resolve(true);
      }, 1200);
    });
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const usersDb = JSON.parse(localStorage.getItem('bgbest_users_db') || '[]');

    if (mode === 'login') {
      const user = usersDb.find((u: any) => u.email === email && u.password === password);
      if (user) {
        if (user.status === 'blocked') return setError('🚫 تم عزل حسابك من قبل النظام المركزي');
        localStorage.setItem('bgbest_user', JSON.stringify(user));
        onLogin();
        navigate(user.role === 'admin' ? '/admin' : '/');
      } else {
        setError('بيانات غير متطابقة مع سجلاتنا');
      }
    } 
    else if (mode === 'signup') {
      if (!validatePassword(password)) {
        return setError('كلمة المرور يجب أن تكون 8 خانات وتحتوي على حرف كبير');
      }
      if (password !== confirmPassword) return setError('عدم تطابق في شفرات المرور');
      if (usersDb.some((u: any) => u.email === email)) return setError('هذا الكيان مسجل مسبقاً');

      setIsProcessing(true);
      const otp = Math.floor(100000 + Math.random() * 900000).toString();
      
      try {
        await sendRealEmail(email, otp);
        setGeneratedOtp(otp);
        setTempUser({ name, email, password });
        setMode('verify');
      } catch (err) {
        setError('فشل في إرسال شفرة الوصول');
      } finally {
        setIsProcessing(false);
      }
    }
  };

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (userOtp === generatedOtp) {
      const usersDb = JSON.parse(localStorage.getItem('bgbest_users_db') || '[]');
      const newUser = { 
        id: 'u_' + Date.now(), 
        ...tempUser, 
        role: 'user', 
        status: 'active',
        joinedDate: new Date().toISOString()
      };
      
      usersDb.push(newUser);
      localStorage.setItem('bgbest_users_db', JSON.stringify(usersDb));

      const adminNotifs = JSON.parse(localStorage.getItem('bgbest_admin_notifications') || '[]');
      adminNotifs.unshift({
        id: Date.now(),
        title: 'عضو جديد انضم للسينما',
        message: `المستخدم ${newUser.name} اخترق نظام التحقق بنجاح.`,
        date: 'الآن',
        isRead: false
      });
      localStorage.setItem('bgbest_admin_notifications', JSON.stringify(adminNotifs));

      setSuccess('تم تفعيل الكيان! سجل دخولك الآن.');
      setMode('login');
      setUserOtp('');
    } else {
      setError('شفرة خاطئة.. حاول مجدداً قبل فوات الأوان');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-black selection:bg-sky-500/30">
      {/* Background Decorative Glows */}
      <div className="fixed top-0 left-0 w-[50vw] h-[50vh] bg-sky-600/5 blur-[150px] -translate-x-1/2 -translate-y-1/2"></div>
      <div className="fixed bottom-0 right-0 w-[40vw] h-[40vh] bg-sky-900/10 blur-[150px] translate-x-1/2 translate-y-1/2"></div>

      <div className="w-full max-w-lg bg-[#050505] border border-white/5 rounded-[4rem] p-12 shadow-[0_40px_100px_rgba(0,0,0,1)] relative overflow-hidden group">
        
        {/* Animated border pulse */}
        <div className="absolute inset-0 border border-sky-500/10 rounded-[4rem] group-hover:border-sky-500/20 transition-all duration-1000"></div>

        <div className="text-center mb-16 relative z-10">
          <h2 className="text-8xl font-black text-white italic tracking-tighter drop-shadow-[0_0_30px_rgba(56,189,248,0.2)]">Bgbest</h2>
          <div className="mt-4 flex flex-col items-center">
            <p className="text-sky-500 font-black text-sm uppercase tracking-[0.6em] mb-1">Bgbest Cinema</p>
            <p className="text-gray-600 font-bold text-[11px] uppercase tracking-widest">بي جي بيست سينما</p>
          </div>
        </div>

        {error && <div className="bg-red-500/5 border border-red-500/20 text-red-500/80 p-6 rounded-3xl text-center text-[11px] font-black mb-8 animate-pulse uppercase tracking-widest">{error}</div>}
        {success && <div className="bg-sky-500/5 border border-sky-500/20 text-sky-400 p-6 rounded-3xl text-center text-[11px] font-black mb-8 uppercase tracking-widest">{success}</div>}

        {mode === 'verify' ? (
          <form onSubmit={handleVerify} className="space-y-8 relative z-10">
            <div className="text-center space-y-2">
               <p className="text-gray-500 text-[10px] font-black uppercase tracking-widest">فك التشفير (6 أرقام)</p>
               <p className="text-white font-black text-lg underline decoration-sky-500/40">{tempUser?.email}</p>
            </div>
            <input 
              required 
              type="text" 
              maxLength={6} 
              placeholder="0 0 0 0 0 0" 
              className="w-full bg-white/[0.02] border border-white/5 p-8 rounded-[2.5rem] text-white text-center text-5xl font-black tracking-[0.2em] outline-none focus:border-sky-500/50 transition-all shadow-inner" 
              value={userOtp} 
              onChange={e => setUserOtp(e.target.value.replace(/\D/g, ''))} 
            />
            <button type="submit" className="w-full bg-white text-black font-black py-7 rounded-[2.5rem] text-xl shadow-2xl hover:bg-sky-500 hover:text-white transition-all transform active:scale-95 leading-none">
              تأكيد الهوية السينمائية
            </button>
          </form>
        ) : (
          <form onSubmit={handleAuth} className="space-y-5 relative z-10">
            {mode === 'signup' && (
              <input required type="text" placeholder="الاسم الكامل" className="w-full bg-white/[0.02] border border-white/5 p-6 rounded-2xl text-white text-right font-bold outline-none focus:border-sky-500/30 transition-all placeholder:text-gray-700" value={name} onChange={e => setName(e.target.value)} />
            )}
            <input required type="email" placeholder="البريد الإلكتروني" className="w-full bg-white/[0.02] border border-white/5 p-6 rounded-2xl text-white text-right font-bold outline-none focus:border-sky-500/30 transition-all placeholder:text-gray-700" value={email} onChange={e => setEmail(e.target.value)} />
            <input required type="password" placeholder="كلمة المرور" className="w-full bg-white/[0.02] border border-white/5 p-6 rounded-2xl text-white text-right font-bold outline-none focus:border-sky-500/30 transition-all placeholder:text-gray-700" value={password} onChange={e => setPassword(e.target.value)} />
            {mode === 'signup' && (
              <input required type="password" placeholder="تأكيد الشفرة" className="w-full bg-white/[0.02] border border-white/5 p-6 rounded-2xl text-white text-right font-bold outline-none focus:border-sky-500/30 transition-all placeholder:text-gray-700" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} />
            )}
            <button type="submit" disabled={isProcessing} className="w-full bg-sky-600 text-white font-black py-7 rounded-[2.5rem] text-xl shadow-[0_20px_60px_rgba(56,189,248,0.2)] transition-all transform active:scale-95 disabled:opacity-50 leading-none">
              {isProcessing ? 'جاري الاتصال بالأعماق...' : mode === 'login' ? 'تسجيل دخول' : 'انضمام للمجتمع'}
            </button>
            <div className="text-center pt-10 border-t border-white/5">
               <button type="button" onClick={() => { setMode(mode === 'login' ? 'signup' : 'login'); setError(''); }} className="text-[10px] text-gray-600 font-black uppercase tracking-[0.3em] hover:text-sky-500 transition-colors">
                 {mode === 'login' ? 'لا تملك كياناً؟ انضم الآن' : 'تملك كياناً؟ سجل دخولك'}
               </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

export default Login;

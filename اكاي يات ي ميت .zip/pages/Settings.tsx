
import React, { useState, useEffect } from 'react';

const Settings: React.FC = () => {
  const [user, setUser] = useState<any>(null);
  const [snowEffect, setSnowEffect] = useState(true);
  const [statusMsg, setStatusMsg] = useState('');

  useEffect(() => {
    const savedUser = localStorage.getItem('bgbest_user');
    if (savedUser) setUser(JSON.parse(savedUser));
    const savedSettings = localStorage.getItem('bgbest_app_settings');
    if (savedSettings) setSnowEffect(JSON.parse(savedSettings).snowEffect !== false);
  }, []);

  const handleSave = () => {
    localStorage.setItem('bgbest_app_settings', JSON.stringify({ snowEffect }));
    setStatusMsg('تم تحديث ترددات العالم بنجاح ✨');
    setTimeout(() => setStatusMsg(''), 3000);
  };

  if (!user) return <div className="pt-40 text-center text-[#38bdf8] font-black">جاري سحب الترددات...</div>;

  return (
    <div className="pt-32 pb-20 px-8 max-w-4xl mx-auto text-right" dir="rtl">
      <h1 className="text-6xl font-black text-white italic mb-16 tracking-tighter leading-none">تخصيص <span className="text-[#38bdf8]">الأعماق</span></h1>
      
      {statusMsg && <div className="mb-10 p-8 bg-[#38bdf8]/10 border border-[#38bdf8]/20 text-[#38bdf8] rounded-[3rem] font-black animate-in fade-in duration-500 shadow-2xl">✨ {statusMsg}</div>}

      <div className="space-y-12">
        <section className="bg-white/[0.02] border border-white/5 p-12 rounded-[4rem] backdrop-blur-3xl shadow-2xl">
          <h2 className="text-2xl font-black text-white mb-12 flex items-center gap-4">
             <div className="w-2 h-8 bg-[#38bdf8] rounded-full"></div>
             بيئة العرض
          </h2>
          <div className="flex items-center justify-between p-10 bg-black/40 rounded-[3rem] border border-white/5 hover:border-[#38bdf8]/30 transition-all">
            <div>
              <p className="font-black text-white text-2xl">الجسيمات النيبولية (Nebula Snow)</p>
              <p className="text-sm text-gray-500 font-bold mt-2 uppercase tracking-widest">Toggle Galactic Particles</p>
            </div>
            <button onClick={() => setSnowEffect(!snowEffect)} className={`w-20 h-10 rounded-full transition-all relative ${snowEffect ? 'bg-[#38bdf8] shadow-[0_0_20px_rgba(56,189,248,0.5)]' : 'bg-gray-800'}`}>
              <div className={`absolute top-2 w-6 h-6 bg-white rounded-full transition-all shadow-xl ${snowEffect ? 'left-2.5' : 'left-11.5'}`}></div>
            </button>
          </div>
        </section>

        <button onClick={handleSave} className="w-full bg-white text-black font-black py-10 rounded-[3.5rem] text-3xl hover:bg-[#38bdf8] hover:text-white transition-all shadow-[0_30px_60px_rgba(255,255,255,0.05)] transform active:scale-95 leading-none">
          تطبيق التعديلات الكونيه
        </button>
      </div>
    </div>
  );
};

export default Settings;

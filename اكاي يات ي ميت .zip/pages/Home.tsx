
import React, { useState, useEffect, useMemo } from 'react';
import MovieCard from '../components/MovieCard';
import { MOCK_MEDIA } from '../constants';
import { MediaItem } from '../types';

const Home: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState('الكل');
  const [searchQuery, setSearchQuery] = useState('');
  const [mediaItems, setMediaItems] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const loadMedia = () => {
      const savedMedia = localStorage.getItem('bgbest_custom_media');
      setMediaItems(savedMedia ? JSON.parse(savedMedia) : MOCK_MEDIA);
      setLoading(false);
    };
    loadMedia();
    const handleSearchEvent = (e: any) => setSearchQuery(e.detail || '');
    window.addEventListener('bgbest_search', handleSearchEvent);
    return () => window.removeEventListener('bgbest_search', handleSearchEvent);
  }, []);

  const categories = ['الكل', 'رمضان 2026', 'أكشن', 'رعب', 'غموض', 'أنمي', 'مدبلج'];

  const filteredItems = useMemo(() => {
    let items = mediaItems;
    if (searchQuery) items = items.filter(m => m.title.includes(searchQuery));
    if (activeCategory !== 'الكل') items = items.filter(i => i.category === activeCategory);
    return items;
  }, [activeCategory, mediaItems, searchQuery]);

  const featured = useMemo(() => mediaItems[0], [mediaItems]);

  if (loading) return null;

  return (
    <div className="pt-0 pb-20">
      {!searchQuery && featured && (
        <section className="relative h-[110vh] w-full overflow-hidden flex items-center justify-end">
          <img src={featured.backdropUrl || featured.posterUrl} className="absolute inset-0 w-full h-full object-cover scale-105 brightness-[0.2] contrast-125" />
          <div className="absolute inset-0 bg-gradient-to-l from-black via-black/60 to-transparent z-10"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent z-10"></div>
          
          <div className="relative z-20 p-8 md:p-32 w-full max-w-7xl text-right animate-in fade-in slide-in-from-right-20 duration-[2000ms]">
            <div className="flex items-center gap-4 justify-end mb-8">
               <span className="text-sky-500 font-black tracking-[0.6em] text-xs uppercase bg-sky-500/10 px-6 py-2 rounded-full border border-sky-500/20">Cinema Selection</span>
               <div className="h-[1px] w-20 bg-sky-500/30"></div>
            </div>
            
            <h1 className="text-[9rem] md:text-[18rem] font-black mb-12 leading-[0.7] tracking-tighter text-white drop-shadow-[0_20px_100px_rgba(56,189,248,0.4)] select-none italic">
              {featured.title}
            </h1>
            
            <p className="text-gray-400 text-2xl md:text-4xl mb-16 line-clamp-2 font-bold max-w-4xl mr-auto leading-tight opacity-90 border-r-4 border-sky-500 pr-8">
              {featured.description}
            </p>
            
            <div className="flex flex-wrap gap-8 justify-end">
              <button 
                onClick={() => window.location.href = `#/media/${featured.id}`}
                className="bg-white hover:bg-sky-500 text-black hover:text-white font-black px-24 py-8 rounded-[2rem] transition-all transform hover:scale-105 shadow-[0_30px_100px_rgba(255,255,255,0.1)] text-3xl flex items-center gap-8 group"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 fill-current group-hover:animate-pulse" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" /></svg>
                بدء العرض الحصري
              </button>
            </div>
          </div>

          <div className="absolute bottom-20 left-32 z-20 hidden lg:block">
             <div className="flex flex-col gap-4 text-gray-600 font-black text-[10px] uppercase tracking-[0.8em] [writing-mode:vertical-rl] rotate-180">
                <span>Mysterious</span>
                <span>Cinematic</span>
                <span>Deep Abyss</span>
             </div>
          </div>
        </section>
      )}

      <div className="max-w-7xl mx-auto px-6 -mt-32 relative z-30">
        <div className="flex items-center gap-4 overflow-x-auto pb-12 no-scrollbar scroll-smooth">
          {categories.map((cat) => (
            <button key={cat} onClick={() => setActiveCategory(cat)} className={`whitespace-nowrap px-14 py-7 rounded-[2.5rem] border transition-all text-xs font-black uppercase tracking-[0.2em] ${activeCategory === cat ? 'bg-sky-500 border-sky-500 text-white shadow-[0_20px_50px_rgba(56,189,248,0.3)]' : 'border-white/5 bg-black/40 text-gray-600 hover:text-white hover:border-white/20 backdrop-blur-3xl'}`}>
              {cat}
            </button>
          ))}
        </div>

        <section className="mt-40">
          <div className="flex items-center justify-between mb-24 border-r-8 border-sky-500 pr-10">
            <div>
               <h2 className="text-6xl font-black text-white tracking-tighter italic">أحدث الاكتشافات السينمائية</h2>
               <p className="text-gray-500 font-bold mt-4 uppercase tracking-[0.4em] text-[10px]">Unveiling the latest secrets of the abyss</p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-14">
            {filteredItems.map((item, idx) => (
              <div key={item.id} className="animate-in fade-in slide-in-from-bottom-20 duration-[1500ms]" style={{ animationDelay: `${idx * 150}ms` }}>
                <MovieCard item={item} />
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default Home;

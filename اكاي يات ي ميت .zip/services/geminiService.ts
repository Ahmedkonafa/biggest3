
import { GoogleGenAI, Modality, Type } from "@google/genai";

// إنشاء مثيل الذكاء الاصطناعي - دائماً ننشئ مثيلاً جديداً لضمان استخدام أحدث مفتاح API كما هو مطلوب
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * توليد بوستر سينمائي احترافي للفيلم
 */
export async function generateMoviePoster(prompt: string) {
  const ai = getAI();
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: `A high-quality cinematic movie poster for: ${prompt}. Dark atmosphere, professional lighting, 4k resolution, no text, artistic style.` }]
      },
      config: {
        imageConfig: {
          aspectRatio: "3:4"
        }
      }
    });

    for (const part of response.candidates[0].content.parts) {
      // البحث عن جزء الصورة، لا نفترض أنه الجزء الأول دائماً في الرد
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
  } catch (e) {
    console.error("Image Gen Error:", e);
    return null;
  }
}

/**
 * محادثة نصية فائقة السرعة بنظام البث (Streaming)
 */
export async function* chatWithGeminiStream(message: string) {
  const ai = getAI();
  const responseStream = await ai.models.generateContentStream({
    model: 'gemini-3-flash-preview',
    // تبسيط contents لتكون نصاً مباشراً لزيادة وضوح الكود وتوافقه مع المعايير
    contents: message,
    config: {
      systemInstruction: `أنت المساعد الحصري والذكي لمنصة "Bgbest". ردودك يجب أن تكون عالمية المستوى، ذكية، سريعة، وبلهجة عربية فخمة.`,
      tools: [{ googleSearch: {} }]
    }
  });

  for await (const chunk of responseStream) {
    yield {
      text: chunk.text,
      // استخراج الروابط من groundingChunks لعرض المصادر بشكل صحيح في واجهة المستخدم
      sources: chunk.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((c: any) => c.web).filter(Boolean) || []
    };
  }
}

/**
 * جلب بيانات فيلم تلقائياً للإدارة
 */
export const fetchMovieMetadata = async (movieName: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `بيانات الفيلم بالتفصيل JSON: ${movieName}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING },
          year: { type: Type.NUMBER },
          category: { type: Type.STRING },
          posterUrl: { type: Type.STRING },
          rating: { type: Type.NUMBER }
        },
        required: ["title", "description", "year", "category"]
      }
    }
  });
  // استخدام .text كخاصية وليس كدالة طبقاً لإرشادات SDK
  return JSON.parse(response.text || '{}');
};

/**
 * الاتصال بالمساعد الصوتي المباشر
 */
export const connectLiveAssistant = (callbacks: any) => {
  const ai = getAI();
  return ai.live.connect({
    model: 'gemini-2.5-flash-native-audio-preview-09-2025',
    callbacks,
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
      },
      systemInstruction: `أنت المساعد الصوتي الرسمي لمنصة "Bgbest". ردودك قصيرة جداً ومباشرة.`,
    },
  });
};

// وظائف الترميز والفك اليدوية المطلوبة للتعامل مع التدفقات الصوتية الخام
export function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

export function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) bytes[i] = binaryString.charCodeAt(i);
  return bytes;
}

// تحديث وظيفة فك تشفير البيانات الصوتية لتطابق معايير Live API وتدعم القنوات المتعددة ومعدل العينة المتغير
export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number = 24000,
  numChannels: number = 1,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

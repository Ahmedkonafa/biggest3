
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate, Link } from 'react-router-dom';
import Navbar from './components/Navbar';
import MobileBottomNav from './components/MobileBottomNav';
import Home from './pages/Home';
import MovieDetails from './pages/MovieDetails';
import Login from './pages/Login';
import Contact from './pages/Contact';
import AdminDashboard from './pages/AdminDashboard';
import Settings from './pages/Settings';
import GeminiAssistant from './components/GeminiAssistant';
import CinematicIntro from './components/CinematicIntro';

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [showIntro, setShowIntro] = useState<boolean>(false);

  useEffect(() => {
    const user = localStorage.getItem('bgbest_user');
    if (user) {
      setIsLoggedIn(true);
      if (!sessionStorage.getItem('bgbest_intro_shown')) {
        setShowIntro(true);
      }
    }
    setLoading(false);
  }, []);

  const handleIntroComplete = () => {
    setShowIntro(false);
    sessionStorage.setItem('bgbest_intro_shown', 'true');
  };

  const handleLogout = () => {
    localStorage.removeItem('bgbest_user');
    sessionStorage.removeItem('bgbest_intro_shown');
    setIsLoggedIn(false);
  };

  if (loading) return null;

  return (
    <Router>
      <div className="min-h-screen bg-[#0a0a0a] text-white selection:bg-sky-600/30 flex flex-col">
        {showIntro && isLoggedIn && <CinematicIntro onComplete={handleIntroComplete} />}
        
        {isLoggedIn && !showIntro && <Navbar onLogout={handleLogout} />}
        
        <main className={`flex-grow ${isLoggedIn && !showIntro ? "pb-20 md:pb-0" : ""}`}>
          <Routes>
            {!isLoggedIn ? (
              <>
                <Route path="/login" element={<Login onLogin={() => setIsLoggedIn(true)} />} />
                <Route path="*" element={<Navigate to="/login" replace />} />
              </>
            ) : (
              <>
                <Route path="/" element={<Home />} />
                <Route path="/media/:id" element={<MovieDetails />} />
                <Route path="/contact" element={<Contact />} />
                <Route path="/admin" element={<AdminDashboard />} />
                <Route path="/settings" element={<Settings />} />
                <Route path="/login" element={<Navigate to="/" replace />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </>
            )}
          </Routes>
        </main>

        {isLoggedIn && !showIntro && (
          <>
            <GeminiAssistant />
            <footer className="bg-black/90 border-t border-white/5 py-12 mt-20 text-center px-6 relative z-10 mb-16 md:mb-0">
               <div className="max-w-7xl mx-auto">
                 <div className="flex flex-wrap justify-center gap-8 md:gap-16 mb-8 text-[11px] font-black text-gray-500 uppercase tracking-widest">
                    <Link to="/contact" className="hover:text-sky-500 transition-colors">سياسة الخصوصية</Link>
                    <Link to="/contact" className="hover:text-sky-500 transition-colors">حقوق الملكية</Link>
                    <Link to="/contact" className="hover:text-sky-500 transition-colors">الدعم الفني</Link>
                 </div>
                 
                 <div className="space-y-4">
                    <h2 className="text-2xl font-black italic text-sky-600 opacity-50 select-none">Bgbest</h2>
                    <div className="space-y-1">
                      <p className="text-gray-600 text-[10px] font-black">
                        جميع الحقوق محفوظة لمنصة Bgbest السينمائية الذكية © {new Date().getFullYear()}
                      </p>
                      <p className="text-gray-700 text-[9px] font-bold">
                        تاريخ التأسيس: يناير 2024 | الإصدار: v2.5.0-Cinema
                      </p>
                    </div>
                 </div>
               </div>
            </footer>
            <MobileBottomNav />
          </>
        )}
      </div>
    </Router>
  );
};

export default App;
